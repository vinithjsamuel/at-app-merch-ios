angular.module("mobile-angular-ui", [
  'mobile-angular-ui.pointer-events',
  'mobile-angular-ui.active-links',
  'mobile-angular-ui.fastclick',
  'mobile-angular-ui.scrollable',
  'mobile-angular-ui.directives.toggle',
  'mobile-angular-ui.directives.overlay',
  'mobile-angular-ui.directives.forms',
  'mobile-angular-ui.directives.panels',
  'mobile-angular-ui.directives.capture',
  'mobile-angular-ui.directives.sidebars',
  'mobile-angular-ui.directives.navbars',
  'mobile-angular-ui.directives.carousel'
 ]);